//font-family change
font = '"meiryo"';
//$('.home').css('font-family',font);
//$('.inputpassword').css('font-family',font);
//$('.inputtext').css('font-family',font);
//$('.uiButtonText').css('font-family',font);
//$('.uiButton').css('font-family',font);

//$('textarea').css('font-family',font);
$('body').css('font-family',font);
//$('input').css('font-family',font);
//alert('loaded');